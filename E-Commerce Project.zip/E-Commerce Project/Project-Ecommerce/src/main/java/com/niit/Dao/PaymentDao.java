package com.niit.Dao;

public interface PaymentDao {
	boolean PaymentDone();

}
