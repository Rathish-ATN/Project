/*package com.niit.Controller;

import com.niit.model.User;

public class MainApp {
	public static void main() {
		// TODO Auto-generated constructor stub
		UserController uc=new UserController();
		User us=new User();
		us.setAddress("sample");
		us.setEmail("sample@123");
		us.setMobile(321654);
		us.setName("sample");
		uc.saveUser(us);
		
	}
}
*/