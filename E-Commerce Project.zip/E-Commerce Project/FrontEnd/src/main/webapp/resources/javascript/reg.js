
  <!--start product slider-->
   
  $(document).ready(function() {
    $('#myCarousel').carousel({
	    interval: 10000
	})
});
    
    <!--end product slider-->