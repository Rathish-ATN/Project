package niit;

public interface InterF1 {
	void off();

}
