package niit;

public interface InterF2 {
	void on();

}
