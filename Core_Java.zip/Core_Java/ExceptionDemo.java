import java.util.Scanner;
public class ExceptionDemo {
	
	public static void main(String[] args) {
		double a;
		double num=9;
		Scanner input=new Scanner(System.in);
		int b=input.nextInt();
		try
		{
			a = 10/0;	
			System.out.println(a);
			//input.close();
		}
		catch(Exception e){
			System.out.println(e);}
	}	
	

}
