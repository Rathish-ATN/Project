
public class InterfaceDemo implements niit.InterF1,niit.InterF2 {
	public void on()
	{
		System.out.println("Switched ON");
	}
	public void off()
	{
		System.out.println("Switched OFF");
	}
	public static void main(String[] args)
	{
		InterfaceDemo obj =new InterfaceDemo();
		obj.on();
		obj.off();
	}
	

}
