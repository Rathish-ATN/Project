
public class StaticDemo {
	static void print1()
	{
		System.out.println("This is static method");
	}
	void print2()
	{
		System.out.println("This is normal method");
	}
	StaticDemo()
	{
		System.out.println("This is a Constructor");
	}
	public static void main(String[] args) 
	{
		StaticDemo obj= new StaticDemo();
		obj.print2();
		print1();
	 	
	}

}
