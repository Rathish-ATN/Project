import niit.*;

public interface InterfaceDemo1 extends InterF1,InterF2 {
	public class InterfaceDemo
	{
	public void on()
	{
		System.out.println("Switched ON");
	}
	public void off()
	{
		System.out.println("Switched OFF");
	}
	public static void main(String[] args) {
		InterfaceDemo obj =new InterfaceDemo();
		obj.on();
		obj.off();
	}
}
}